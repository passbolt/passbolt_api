-- phpMyAdmin SQL Dump
-- version 3.2.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 07, 2010 at 06:52 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `passkeeper`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `comment` text,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `root_id` int(10) unsigned DEFAULT NULL,
  `lft` mediumint(8) unsigned DEFAULT NULL,
  `rght` mediumint(8) unsigned DEFAULT NULL,
  `level` mediumint(8) unsigned DEFAULT NULL,
  `category_type_id` tinyint(4) unsigned NOT NULL DEFAULT '1' COMMENT 'type of category',
  PRIMARY KEY (`id`),
  KEY `rght` (`root_id`,`rght`,`lft`) USING BTREE,
  KEY `lft` (`root_id`,`lft`,`rght`) USING BTREE,
  KEY `parent_id` (`parent_id`,`created`) USING BTREE
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=75 ;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `comment`, `created`, `modified`, `parent_id`, `root_id`, `lft`, `rght`, `level`, `category_type_id`) VALUES
(56, 'Default', NULL, '2010-11-07 14:00:17', '2010-11-07 14:00:17', NULL, 56, 1, 38, 0, 1),
(57, 'category 1', NULL, '2010-11-07 14:00:17', '2010-11-07 14:00:17', 56, 56, 2, 9, 1, 1),
(58, 'category 2', NULL, '2010-11-07 14:00:17', '2010-11-07 14:00:17', 56, 56, 10, 37, 1, 1),
(59, 'SubCat 1', NULL, '2010-11-07 14:00:17', '2010-11-07 14:00:17', 57, 56, 3, 4, 2, 1),
(60, 'category 2', NULL, '2010-11-07 14:01:42', '2010-11-07 14:01:42', 57, 56, 5, 8, 2, 1),
(61, 'category 1', NULL, '2010-11-07 14:02:01', '2010-11-07 14:02:01', 58, 56, 11, 36, 2, 1),
(62, 'SubCat 1', NULL, '2010-11-07 14:02:01', '2010-11-07 14:02:01', 61, 56, 12, 17, 3, 1),
(63, 'category 2', NULL, '2010-11-07 14:02:01', '2010-11-07 14:02:01', 61, 56, 18, 23, 3, 1),
(64, 'subCat1', NULL, '2010-11-07 14:03:29', '2010-11-07 14:03:29', 60, 56, 6, 7, 3, 1),
(65, 'category 2', NULL, '2010-11-07 14:03:36', '2010-11-07 14:03:36', 63, 56, 19, 22, 4, 1),
(66, 'subCat1', NULL, '2010-11-07 14:03:36', '2010-11-07 14:03:36', 65, 56, 20, 21, 5, 1),
(67, 'category 2', NULL, '2010-11-07 14:09:28', '2010-11-07 14:09:29', 62, 56, 13, 16, 4, 1),
(68, 'subCat1', NULL, '2010-11-07 14:09:29', '2010-11-07 14:09:29', 67, 56, 14, 15, 5, 1),
(69, 'subcat3', NULL, '2010-11-07 14:10:28', '2010-11-07 14:10:28', 61, 56, 24, 29, 3, 1),
(70, 'category 2', NULL, '2010-11-07 14:10:37', '2010-11-07 14:10:37', 69, 56, 25, 28, 4, 1),
(71, 'subCat1', NULL, '2010-11-07 14:10:37', '2010-11-07 14:10:37', 70, 56, 26, 27, 5, 1),
(72, 'subcat4', NULL, '2010-11-07 14:14:32', '2010-11-07 14:14:32', 61, 56, 30, 35, 3, 1),
(73, 'category 2', NULL, '2010-11-07 14:14:59', '2010-11-07 14:14:59', 72, 56, 31, 34, 4, 1),
(74, 'subCat11', NULL, '2010-11-07 14:14:59', '2010-11-07 14:15:22', 73, 56, 32, 33, 5, 1);

-- --------------------------------------------------------

--
-- Table structure for table `category_types`
--

CREATE TABLE IF NOT EXISTS `category_types` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `description` text COLLATE utf8_bin NOT NULL,
  `icon` varchar(255) COLLATE utf8_bin NOT NULL,
  `live` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=3 ;

--
-- Dumping data for table `category_types`
--

INSERT INTO `category_types` (`id`, `name`, `description`, `icon`, `live`) VALUES
(1, 'default', 0x64656661756c742074797065206f662063617465676f7279, 'default.png', 1),
(2, 'root', 0x646174616261736520747970652c20666f722074686520726f6f7420666f6c646572, 'database.png', 1);

-- --------------------------------------------------------

--
-- Table structure for table `passwords`
--

CREATE TABLE IF NOT EXISTS `passwords` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8_bin NOT NULL,
  `username` varchar(50) COLLATE utf8_bin NOT NULL,
  `password` varchar(255) COLLATE utf8_bin NOT NULL,
  `url` varchar(255) COLLATE utf8_bin NOT NULL,
  `comment` text COLLATE utf8_bin,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=9 ;

--
-- Dumping data for table `passwords`
--

INSERT INTO `passwords` (`id`, `category_id`, `title`, `username`, `password`, `url`, `comment`) VALUES
(1, 0, 'administrator', 'kevin', 'KNOWLEDGE', '', 0x636f6d6d656e742074657374),
(2, 0, 'test', 'test', 'test', 'test', 0x646173647361),
(3, 0, '', '', '', '', ''),
(4, 0, 'this is a test', 'kevos', '●●●●●●●●●●●', '92.121.93.82', 0x7465737432),
(5, 0, 'test', 'test', 'test', '91.121.93.82', 0x74657374),
(6, 0, 'test1', 'dsadsa', 'dsadsa', 'dsadsa', 0x647361647361),
(7, 0, 'test', 'test', 'test', 'test', 0x64736164736461647361),
(8, 0, 'test', 'test', 'test', '91.121.93.82', 0x646173646173646173);
