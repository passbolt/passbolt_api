-- phpMyAdmin SQL Dump
-- version 3.2.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 24, 2010 at 09:20 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `passkeeper`
--

-- --------------------------------------------------------

--
-- Table structure for table `acos`
--

CREATE TABLE IF NOT EXISTS `acos` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `model` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `alias` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=3 ;

--
-- Dumping data for table `acos`
--

INSERT INTO `acos` (`id`, `model`, `alias`) VALUES
(1, 'Category', 'category'),
(2, 'Password', 'password');

-- --------------------------------------------------------

--
-- Table structure for table `aros`
--

CREATE TABLE IF NOT EXISTS `aros` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `model` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `alias` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=3 ;

--
-- Dumping data for table `aros`
--

INSERT INTO `aros` (`id`, `model`, `alias`) VALUES
(1, 'Group', 'group'),
(2, 'User', 'user');

-- --------------------------------------------------------

--
-- Table structure for table `aros_acos`
--

CREATE TABLE IF NOT EXISTS `aros_acos` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `aro_id` int(10) NOT NULL,
  `aco_id` int(10) NOT NULL,
  `_create` varchar(2) COLLATE utf8_bin NOT NULL DEFAULT '0',
  `_read` varchar(2) COLLATE utf8_bin NOT NULL DEFAULT '0',
  `_update` varchar(2) COLLATE utf8_bin NOT NULL DEFAULT '0',
  `_delete` varchar(2) COLLATE utf8_bin NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ARO_ACO_KEY` (`aro_id`,`aco_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=1 ;

--
-- Dumping data for table `aros_acos`
--


-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `comment` text,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `root_id` int(10) unsigned DEFAULT NULL,
  `lft` mediumint(8) unsigned DEFAULT NULL,
  `rght` mediumint(8) unsigned DEFAULT NULL,
  `level` mediumint(8) unsigned DEFAULT NULL,
  `category_type_id` tinyint(4) unsigned NOT NULL DEFAULT '1' COMMENT 'type of category',
  PRIMARY KEY (`id`),
  KEY `rght` (`root_id`,`rght`,`lft`) USING BTREE,
  KEY `lft` (`root_id`,`lft`,`rght`) USING BTREE,
  KEY `parent_id` (`parent_id`,`created`) USING BTREE
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `comment`, `created`, `modified`, `parent_id`, `root_id`, `lft`, `rght`, `level`, `category_type_id`) VALUES
(1, 'Default', NULL, '2010-11-13 11:13:47', '2010-11-13 11:13:47', NULL, 1, 1, 16, 0, 1),
(2, 'kotow', NULL, '2010-11-13 11:13:47', '2010-11-13 11:15:02', 1, 1, 2, 9, 1, 1),
(3, 'neemrana', NULL, '2010-11-13 11:13:47', '2010-11-13 11:15:39', 1, 1, 10, 15, 1, 1),
(4, 'dev', NULL, '2010-11-13 11:13:47', '2010-11-13 11:15:29', 2, 1, 3, 4, 2, 1),
(5, 'prod', NULL, '2010-11-13 11:15:33', '2010-11-13 11:15:33', 2, 1, 5, 8, 2, 1),
(6, 'dev', NULL, '2010-11-13 11:15:44', '2010-11-15 13:44:25', 5, 1, 6, 7, 3, 1),
(7, 'prod', NULL, '2010-11-13 11:15:50', '2010-11-13 11:15:50', 3, 1, 11, 14, 2, 1),
(8, 'test', NULL, '2010-11-15 13:44:53', '2010-11-15 13:44:53', 7, 1, 12, 13, 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `category_types`
--

CREATE TABLE IF NOT EXISTS `category_types` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `description` text COLLATE utf8_bin NOT NULL,
  `icon` varchar(255) COLLATE utf8_bin NOT NULL,
  `live` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=3 ;

--
-- Dumping data for table `category_types`
--

INSERT INTO `category_types` (`id`, `name`, `description`, `icon`, `live`) VALUES
(1, 'default', 0x64656661756c742074797065206f662063617465676f7279, 'default.png', 1),
(2, 'root', 0x646174616261736520747970652c20666f722074686520726f6f7420666f6c646572, 'database.png', 1);

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE IF NOT EXISTS `groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `parent_id` int(11) NOT NULL,
  `root_id` int(11) NOT NULL,
  `lft` int(11) NOT NULL,
  `rght` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=18 ;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `name`, `parent_id`, `root_id`, `lft`, `rght`, `level`) VALUES
(17, 'Sysadmin', 0, 17, 1, 2, 0),
(16, 'Team Leaders', 14, 13, 3, 4, 2),
(15, 'Designers', 13, 13, 6, 7, 1),
(14, 'Programmers', 13, 13, 2, 5, 1),
(13, 'Webdev', 0, 13, 1, 8, 0);

-- --------------------------------------------------------

--
-- Table structure for table `groups_users`
--

CREATE TABLE IF NOT EXISTS `groups_users` (
  `group_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`group_id`,`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `groups_users`
--

INSERT INTO `groups_users` (`group_id`, `user_id`) VALUES
(13, 16),
(14, 16),
(15, 9),
(15, 16),
(16, 8),
(16, 16),
(17, 9);

-- --------------------------------------------------------

--
-- Table structure for table `passwords`
--

CREATE TABLE IF NOT EXISTS `passwords` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8_bin NOT NULL,
  `username` varchar(50) COLLATE utf8_bin NOT NULL,
  `password` varchar(255) COLLATE utf8_bin NOT NULL,
  `url` varchar(255) COLLATE utf8_bin NOT NULL,
  `comment` text COLLATE utf8_bin,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=25 ;

--
-- Dumping data for table `passwords`
--

INSERT INTO `passwords` (`id`, `category_id`, `title`, `username`, `password`, `url`, `comment`) VALUES
(1, 0, 'administrator', 'kevin', 'KNOWLEDGE', '', 0x636f6d6d656e742074657374),
(2, 0, 'test', 'test', 'test', 'test', 0x646173647361),
(3, 0, '', '', '', '', ''),
(4, 0, 'this is a test', 'kevos', '●●●●●●●●●●●', '92.121.93.82', 0x7465737432),
(5, 0, 'test', 'test', 'test', '91.121.93.82', 0x74657374),
(6, 0, 'test1', 'dsadsa', 'dsadsa', 'dsadsa', 0x647361647361),
(7, 0, 'test', 'test', 'test', 'test', 0x64736164736461647361),
(8, 0, 'test', 'test', 'test', '91.121.93.82', 0x646173646173646173),
(9, 58, 'passwordcat2', 'test', 'test', '91.121.93.82', 0x74657374636f6d6d656e74),
(10, 56, 'passwordtest1', 'kevin', 'knowledge', '91.121.93.82', 0x647361647361647361),
(11, 59, 'my foot', 'kev', 'password', '91.121.93.82', 0x7468697320697320612074657374),
(12, 56, 'test1', 'kmuller', 'knowledge', '91.121.93.82', 0x7468697320697320612074657374),
(13, 56, 'kevos', 'knowledge', 'knowledge', '91.121.93.82', 0x74657374),
(14, 56, 'test1', 'test2', 'test4', 'test5', 0x6461646173646173),
(15, 56, 'kevos', 'knowledge', 'dadasd', 'dsadasd', 0x646461736461646173),
(16, 56, 'test3', 'kevos', 'knowledge', '91.121.93.82', 0x646173647361647361),
(17, 56, 'test4', 'knowledge', 'knowledge', '91.121.93.82', 0x64616473647361),
(18, 56, 'test1', 'test2', 'test4', '91.121.93.82', 0x6461736461),
(19, 56, 'root', 'password', '91.121.93.82', 'dasdas', 0x646173647361),
(20, 56, 'test1', 'test', 'dasdsa', 'dsada', 0x6461647361),
(21, 56, 'dsad', 'dasdas', 'daads', 'dasda', 0x6461736461),
(22, 1, 'root', 'root', '8xdygkc1b9', '91.121.93.76', 0x626c61626c61),
(23, 5, 'testprod', 'mynameisgnu', 'knowledge', '91.121.93.82', 0x7468697320697320612074657374),
(24, 8, 'vidhat', 'vidhat', 'dadass', 'dasdsa', 0x6461736473617361);

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE IF NOT EXISTS `permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `aco_id` tinyint(4) NOT NULL,
  `aco_ref_id` int(10) unsigned NOT NULL,
  `aro_id` tinyint(4) NOT NULL,
  `aro_ref_id` int(10) unsigned NOT NULL,
  `_read` tinyint(1) NOT NULL,
  `_write` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=10 ;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `aco_id`, `aco_ref_id`, `aro_id`, `aro_ref_id`, `_read`, `_write`) VALUES
(1, 1, 56, 1, 64, 1, 1),
(3, 0, 18, 0, 18, 1, 1),
(4, 1, 18, 2, 18, 1, 1),
(5, 1, 1, 1, 13, 0, 0),
(6, 1, 5, 1, 13, 1, 0),
(7, 1, 5, 1, 17, 0, 1),
(8, 1, 5, 2, 9, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` char(50) COLLATE utf8_bin DEFAULT NULL,
  `password` char(40) COLLATE utf8_bin DEFAULT NULL,
  `name` varchar(100) COLLATE utf8_bin NOT NULL,
  `email` varchar(255) COLLATE utf8_bin NOT NULL,
  `address` text COLLATE utf8_bin,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=17 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `name`, `email`, `address`, `active`, `created`, `modified`) VALUES
(9, 'Alka', 'test4', 'Alka Choudhary', 'alka@gmail.com', 0x33302072616a616d616e6e617220737472656574, 1, '2010-11-14 00:00:00', '2010-11-14 00:00:00'),
(8, 'vidhat2', 'test', 'vidhatanand great', 'vidhatanand@gmail.com', 0x6438382f32206f6b686c612070686173652049, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(10, 'jeanclaude', 'password', 'Jean Claude Vandamme', 'jcvandamme@gmail.com', 0x61647265737365206465206a65616e20636c61756465, 1, '2010-11-20 19:25:16', '2010-11-20 19:25:16'),
(11, 'marieantoinette', 'pasword', 'Marie Antoinette', 'marie@gmail.com', 0x74657374, 1, '2010-11-20 19:28:43', '2010-11-20 19:28:43'),
(12, 'jj', 'jjpassword', 'Jean Jacques', 'jj@wanadoo.fr', 0x647361647361647361, 1, '2010-11-20 19:30:05', '2010-11-20 19:30:05'),
(13, '', '', '', '', '', 1, '2010-11-20 20:23:39', '2010-11-20 20:23:39'),
(14, '', '', '', '', '', 1, '2010-11-20 20:25:12', '2010-11-20 20:25:12'),
(15, '', '', '', '', '', 1, '2010-11-20 20:28:31', '2010-11-20 20:28:31'),
(16, 'ewqe', 'eqweq', 'ewqewe', 'wqeeqw', 0x657177657177, 1, '2010-11-20 21:51:36', '2010-11-20 21:51:36');
